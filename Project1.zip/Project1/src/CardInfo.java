/**
 * Created by Will on 1/29/2017.
 */
public class CardInfo
{
    public CardInfo()
    {
        card_number = "";
        name = "";
        expiration_year = "";
        expiration_month = "";
        service_code = "";
        discretionary_data = "";
        pin = "";
        ccv = "";
    }

    public String card_number;
    public String name;
    public String expiration_year;
    public String expiration_month;
    public String service_code;
    public String discretionary_data;
    public String pin;
    public String ccv;
}
